from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView, UpdateView
from .models import Quote, Person
from .forms import CreateQuoteForm, UpdateQuoteForm
import random


# Create your views here.
class HomePageView(ListView):
    """ Showing a listing of Quotes."""
    model = Quote #retrieve QUote objects from the database
    template_name = "quotes/home.html"
    context_object_name = "quotes"

class QuotePageView(DetailView):
    """ Display a single Quote Quotes."""
    model = Quote #retrieve QUote object from the database
    template_name = "quotes/quote.html"
    context_object_name = "quote"

class RandomQuotePageView(DetailView):
    """ Display a single Quote Quotes."""
    model = Quote #retrieve QUote object from the database
    template_name = "quotes/quote.html"
    context_object_name = "quote"

    #overrided a method in the DetailView class
    def get_object(self):
        """Select one quote at random for display in the quote.html template."""
        #obtain all quotes using the object manager
        quotes = Quote.objects.all()
        #select one at random
        q = random.choice(quotes)
        return q


class PersonPageView(DetailView):
    """ Display a single Person Quotes."""
    model = Person #retrieve QUote object from the database
    template_name = "quotes/person.html"
    context_object_name = "person"

class CreateQuoteView(CreateView):
    """ Create a new Quote object and store it in database."""
    model = Quote #whcih quote to create
    form_class = CreateQuoteForm
    template_name = "quotes/create_quote_form.html"


class UpdateQuoteView(UpdateView):
    """ Create a new Quote object and store it in database."""
    model = Quote #whcih quote to create
    form_class = UpdateQuoteForm
    template_name = "quotes/update_quote_form.html"