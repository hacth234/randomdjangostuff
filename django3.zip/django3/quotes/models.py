from django.db import models
import random

from django.urls import reverse #helps us look up a url using a name and also any data needed
# Create your models here.

class Person(models.Model):
    """ Represent a Person who said something notable."""

    name = models.TextField(blank=True)

    def __str__(self):
        """ """
        return self.name

    def get_random_image(self):
        """Return an image of this person, selected"""

        #get all images of this person
        images = Image.objects.filter(person=self)
        #select one at random to return
        return random.choice(images)

    def get_all_quotes(self):
        """Return all quotes for this Person """
        return Quote.objects.filter(person=self)

    
    def get_all_images(self):
        """Return all quotes for this Person """
        return Image.objects.filter(person=self)

        
class Quote(models.Model):
    """ Represents a quote by a famous person"""

    #data atrributes
    text = models.TextField(blank=True)
    # author = models.TextField(blank=True)
    # image_url = models.URLField(blank=True) #anytime we make model we have to rerun migrations commands
    person = models.ForeignKey(Person, on_delete=models.CASCADE)

    def __str__(self):
        """ Return a string representation of this quote."""

        #return f'"{self.text}" - {self.author}'
        return f'"{self.text}" - {self.person}'

    def get_absolute_url(self):
        """ gets an absolute url to redirect to """
        #gives back a reverse lookup for the quote which directs to the url quote thing
        return reverse('quote', kwargs={'pk':self.pk})
    
class Image(models.Model):
    """ Represent an image URL for a Person."""

    image_url = models.URLField(blank=True)
    person = models.ForeignKey(Person, on_delete=models.CASCADE)

    def __str__(self):
        """ return string representation"""
        return self.image_url