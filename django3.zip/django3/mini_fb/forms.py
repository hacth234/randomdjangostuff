#Assignment 18 
#mini_fb/forms.py
#Jun Hao Lei
#junhlei@bu.edu
#Description: All form classes used for mini_fb

from django import forms
from .models import Profile, StatusMessage


class CreateProfileForm(forms.ModelForm):
    """ A form to create a profile"""

    firstname = forms.CharField(label="First Name", required=True)
    lastname = forms.CharField(label="Last Name", required=True)
    city = forms.CharField(label="City", required=True)
    email = forms.CharField(label="Email", required=True)

    # birth_date = forms.DateField(widget=forms.SelectDateWidget(years=range(2012,1920,-1),),)
    #our form class
    class Meta:
        """Additional info fields etc about this form """
        model = Profile #which model to create
        fields = ['firstname', 'lastname', 'city', 'email', 'image_url'] #which fields to create 


class UpdateProfileForm(forms.ModelForm):
    """ A form to update a Quote Object."""
    city = forms.CharField(label="City", required=True)
    email = forms.CharField(label="Email", required=True)
    class Meta:
        """Additional info fields etc about this update form """
        model = Profile #which model to create
        fields = ['city', 'email', 'image_url'] #which fields to create 

class CreateStatusMessageForm(forms.ModelForm):
    """ A form to post messages"""

    class Meta:
        """ Additional fields for it"""
        model = StatusMessage
        fields = ["message"]
        