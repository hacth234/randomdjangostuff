from django.apps import AppConfig


class MiniFbConfig(AppConfig):
    name = 'mini_fb'
