from django.db import models
#from datetime import datetime,dateformat
from django.utils import timezone, dateformat
from django.urls import reverse
# Create your models here.
class Profile(models.Model):
    #data atrributes
    firstname = models.TextField(blank=True)
    lastname= models.TextField(blank=True)
    city = models.TextField(blank=True)
    email = models.TextField(blank=True)
    image_url = models.URLField(blank=True)

    def __str__(self):
        """ Return a string representation of this quote."""
        return f'{self.firstname} - {self.lastname} - {self.city} - {self.email}'

    def get_status_messages(self):
        """ an accessor to get the messages from the profile"""

        return StatusMessage.objects.filter(profile=self)
    
    def get_absolute_url(self):
        """ gets an absolute url to redirect to """
        #gives back a reverse lookup for the quote which directs to the url quote thing
        #uses the name as label in the reverse function from the urls.py file
        return reverse('show_profile_page', kwargs={'pk':self.pk})

class StatusMessage(models.Model):
    # def getCurrentTime():
    #     """ gets a string timestamp """
    #     dateTimeObj = datetime.now()
    #     #timeStr = dateTimeObj.hour + ':' + dateTimeObj.minute + dateTimeObj.
    #     timestr = dateTimeObj.strftime("%I:%M%p")
    #     return timestr
    #timestamp = getCurrentTime()
    #formatted_date = dateformat.format(timezone.now(), 'H:i a')
    timestamp = models.DateTimeField(auto_now_add=True)
    message = models.TextField(blank=True)
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    def __str__(self):
        """ Return a string representation of this message"""
        return f'{self.message}'

    def getTimestamp(self):
        """ a getter for timestamp """
        return f'{self.timestamp}'

